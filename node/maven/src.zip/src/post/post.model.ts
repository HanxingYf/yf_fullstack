// 对数据库的模型定义
export class PostModel {
  id?: number;
  title: string;
  content?: string;
}
import logo from './logo.svg';
import './App.css';
import { Button } from 'antd';

function App() {
  return (
    <div className="App">
      <Button type="primary">点击</Button>
    </div>
  );
}

export default App;

export const CHANGE_USER_INFO = "user/login/CHANGE_USER_INFO";

export const CHANGE_SENT_STATUS = "user/login/CHANGE_SENT_STATUS";

export const CHANGE_LOGIN_STATUS = "user/login/CHANGE_LOGIN_STATUS";
